
------------------ ScanSpect README LINUX --------------------


Per poter usare ScanSpect su Linux occorre:

1. vere Python3

2. installare le seguenti librerie con il pip:

 	pip install opencv-python
	pip install pillow
 	pip install mysql-connector-python
 	sudo apt-get install python3-tk

3. Eseguire il client tramite il comando 'python3 FaceRec.py'

--------------------------------------------------------------