<?php
    //First argument username, second argument password. You must to have the access to database ScanSpect and to create table.
    return ["normalUser", "Normal_1"];
?>