<?php
    //Set the route of the site. At the end you must add '/';
    return "http://localhost:8080/";
?>